#!/bin/sh

DATE=$(date +%Y-%m-%d)
BACKUP_DIR="/backup"
FILENAME="backup_$DATE.tar.gz"

# Tee varukoopia Manager.io andmetest
tar -czf $BACKUP_DIR/$FILENAME /data

echo "Varukoopia tehtud: $FILENAME"

# Kustuta vanemad kui 7 päeva
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Vanad varukoopiad kustutatud"
