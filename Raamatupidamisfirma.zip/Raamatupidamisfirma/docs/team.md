# Meeskond

## Liikmed

| Nimi | Roll | Ülesanded |
|---|---|---|
| Johannes | Otsustav isik / projektijuht | GitHubi haldus, dokumentatsioon, projekti koordineerimine |
| Erik | Liige | Serverite ja Docker keskkonna seadistamine |
| Kennerth | Liige | Teenuste (Nginx, Manager.io, backup) seadistamine |

---

## Stsenaarium

| Parameeter | Väärtus |
|---|---|
| Kasutajate arv | 17 |
| Ettevõtte tüüp | Raamatupidamisfirma |
| Eritingimus | Varukoopiad on kohustuslikud |

---

## Kasutatud tarkvara

| Tarkvara | Põhjus |
|---|---|
| Manager.io | Tasuta, self-hosted raamatupidamistarkvara, sobib 17 kasutajale |
| Docker | Lihtsustab teenuste käivitamist ja haldamist |
| Nginx | Turvaline reverse proxy, peidab Manager.io otse interneti eest |
