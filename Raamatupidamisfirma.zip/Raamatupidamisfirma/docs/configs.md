# Konfiguratsioonifailid

## Üldine

Projekt kasutab Dockerit, seetõttu on enamus konfiguratsioonist kirjeldatud failides, mitte käsitsi serveris seadistatud.

---

## docker-compose.yml

See fail kirjeldab kogu süsteemi teenuseid ja nende omavahelisi seoseid.

Selles failis on defineeritud:

- Nginx (reverse proxy)
- Manager.io (raamatupidamistarkvara)
- Backup teenus

Lisaks määratakse:

- võrgud (networking)
- andmete salvestus (volumes)
- teenuste sõltuvused (depends_on)

---

## nginx.conf

Nginx konfiguratsioon suunab kõik päringud Manager.io teenusele.

- Kuulab port 80
- Suunab liikluse `manager:8080` aadressile
- Edastab kasutaja IP aadressi päistes

---

## .env.example

Sisaldab keskkonnamuutujaid, mida kasutatakse süsteemi seadistamiseks.

Näited:

- `MANAGER_PORT`
- `BACKUP_RETENTION_DAYS`

See fail on ainult näidis ja ei sisalda päris tundlikke andmeid. Kopeeri see `.env` nimega ja muuda väärtused.

---

## backup.sh

Bash skript, mis käivitub automaatselt ja teeb varukoopiaid Manager.io andmetest.

- Teeb igapäevase varukoopia
- Salvestab `/backup` kausta
- Kustutab vanemad kui 7 päeva varukoopiad

---

## Volumes

Docker volumes kasutatakse andmete püsivaks salvestamiseks.

- `manager_data` – Manager.io kõik andmed (säilivad ka pärast taaskäivitust)
- `backup_data` – varukoopiad
