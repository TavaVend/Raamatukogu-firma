# Raamatupidamisfirma IT infrastruktuur

Süsteemi eesmärk on pakkuda väikesele raamatupidamisfirmale (17 kasutajat) keskset ja turvalist keskkonda finantsandmete haldamiseks, kasutades ise hostitavat raamatupidamistarkvara Manager.io.

---

## Arhitektuur

Süsteem koosneb järgmistest teenustest:

- **Nginx** – reverse proxy (suunab liikluse Manager.io-le)
- **Manager.io** – raamatupidamistarkvara
- **Backup teenus** – automaatne varundamine (kohustuslik)

**Andmevoog:** Kasutaja → Nginx → Manager.io

---

## Kasutatavad tehnoloogiad

- Docker
- Docker Compose
- Nginx
- Manager.io
- Bash (varundamine)

---

## Käivitamine

1. Kopeeri keskkonnamuutujad: `cp .env.example .env`
2. Muuda `.env` failis vajalikud väärtused
3. Käivita teenused: `docker-compose up -d`
4. Kontrolli et kõik töötab: `docker-compose ps`
5. Ava brauser: `http://localhost`

---

## Dokumentatsioon

- [Projekti kirjeldus](docs/project.md)
- [Arhitektuur](docs/architecture.md)
- [Konfiguratsioonifailid](docs/configs.md)
- [Meeskond](docs/team.md)
